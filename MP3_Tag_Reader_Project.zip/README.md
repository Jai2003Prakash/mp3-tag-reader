
# MP3 Tag Reader

## Objective
To read and display MP3 metadata (ID3 tags) such as Title, Artist, Album, and Year.

## Description
This project demonstrates file handling and binary parsing concepts by extracting ID3 tags from MP3 files.

## Features
- Reads MP3 header
- Extracts ID3 tag information
- Displays metadata to the user

## Compilation
```bash
gcc *.c -o mp3_tag_reader
```

## Execution
```bash
./mp3_tag_reader song.mp3
```

## Author
Vel Tech – Linux Internals Lab
